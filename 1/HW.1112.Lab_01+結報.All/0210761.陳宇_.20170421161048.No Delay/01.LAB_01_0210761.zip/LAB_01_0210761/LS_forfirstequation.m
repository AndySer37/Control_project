theta = Data_rad(1:20);
w = omega_smooth2(1:20);
tire_speed = Data_rad(1:20,3);
tire_angle_speed = tire_speed/3.45;   %�t�״������t��(rad/s)

for i=1:(length(w)-1)
    W(i) = (w(i+1) - w(i))/0.01;
end
W(length(w)) = W(length(w)-1);

for i=1:(length(tire_angle_speed)-1)
    tire_angle_acceleration(i) = (tire_angle_speed(i+1) - tire_angle_speed(i))/0.01;
end
tire_angle_acceleration(length(w)) = tire_angle_acceleration(length(w)-1);

A = zeros(length(w),5);
A(:,1) = -W';
A(:,2) = -(2*cos(theta').*W'-sin(2*theta').*sec(theta').*w');
A(:,3) = w';
A(:,4) = -tire_angle_speed';
A(:,5) = 100; %Vs

b = transpose(tire_angle_acceleration);

x = inv(transpose(A)*A)*transpose(A)*b;

sigma1 = x(1)
sigma2 = x(2)
sigma3 = x(3)
sigma4 = x(4)
sigma5 = x(5)

%rho3 = x(1)    %-10.932019402580760
%rho4 = x(2)    %-39.402306014934040