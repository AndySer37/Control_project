figure
plot(Ow_dot_smooth2);

figure
plot(Ow_dot_dot_smooth);
 
 

figure
plot(angle_smooth2);

figure
plot(omega_smooth2);

figure
plot(omega_dot_smooth);