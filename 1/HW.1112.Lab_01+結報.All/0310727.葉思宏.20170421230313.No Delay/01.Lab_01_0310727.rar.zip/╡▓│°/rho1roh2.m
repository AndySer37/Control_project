theta = omega_dot_smooth(40:80);
w = omega_smooth2(40:80);
for i=40:80
    a = i-39;
    b  = cos(angle_smooth2(i)) * Ow_dot_dot_smooth(i);
    k(a)=b;
end
W = omega_dot_smooth(40:80) + 0.061*(Ow_dot_smooth2(40:80) + omega_smooth2(40:80)) -0.2691*sin(angle_smooth2(40:80)) 

A = zeros(length(w),2);
A(:,1) = theta';
A(:,2) = k'; 

b = transpose(W);

x = inv(transpose(A)*A)*transpose(A)*b;

rho1 = x(1)    %-10.932019402580760
rho2 = x(2)    %-39.402306014934040