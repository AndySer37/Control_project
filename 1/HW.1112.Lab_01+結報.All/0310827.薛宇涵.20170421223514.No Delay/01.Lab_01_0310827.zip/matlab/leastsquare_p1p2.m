 %ANGLE DIFFERENCIATION==========================================================================================
 angle = buf(:,1);
 t = 0.1;
 angle_smooth = angle;

for i=2:length(angle_smooth)
    omega(i-1) = (angle_smooth(i)-angle_smooth(i-1))*1.0/t;
end
 omega(length(angle_smooth)) = omega(length(angle_smooth)-1);
 %����
 omega_smooth(1) = omega(1);
 omega_smooth(2) = omega(2);
 for i=3:length(omega)-2
    omega_smooth(i) = (omega(i-2)+omega(i-1)+omega(i)+omega(i+1)+omega(i+2))/5.0;
 end
 omega_smooth(length(omega)-1) = omega_smooth(length(omega)-2);
 omega_smooth(length(omega)) = omega_smooth(length(omega)-1);
 
 omega_smooth2 = omega_smooth;
 for i=3:length(omega)-2
    omega_smooth2(i) = (omega_smooth2(i-2)+omega_smooth2(i-1)+omega_smooth2(i)+omega_smooth2(i+1)+omega_smooth2(i+2))/5.0;
 end
 omega_smooth2(length(omega)-1) = omega_smooth2(length(omega)-2);
 omega_smooth2(length(omega)) = omega_smooth2(length(omega)-1);
 
 w_smooth=omega_smooth2;
 
 figure
 plot(buf(:,1));
 figure
 plot(buf(:,2));
 figure
 plot(buf(:,3));
 
 figure
 plot(angle);
 figure
 plot(w_smooth);
 
 %WHEEL DIFFERENCIATION==========================================================================================
 angle = buf(:,3)/3.45;     %w=v/r
 t = 0.1;
 angle_smooth = angle;

for i=2:length(angle_smooth)
    omega(i-1) = (angle_smooth(i)-angle_smooth(i-1))*1.0/t;
end
 omega(length(angle_smooth)) = omega(length(angle_smooth)-1);
 %����
 omega_smooth(1) = omega(1);
 omega_smooth(2) = omega(2);
 for i=3:length(omega)-2
    omega_smooth(i) = (omega(i-2)+omega(i-1)+omega(i)+omega(i+1)+omega(i+2))/5.0;
 end
 omega_smooth(length(omega)-1) = omega_smooth(length(omega)-2);
 omega_smooth(length(omega)) = omega_smooth(length(omega)-1);
 
 omega_smooth2 = omega_smooth;
 for i=3:length(omega)-2
    omega_smooth2(i) = (omega_smooth2(i-2)+omega_smooth2(i-1)+omega_smooth2(i)+omega_smooth2(i+1)+omega_smooth2(i+2))/5.0;
 end
 omega_smooth2(length(omega)-1) = omega_smooth2(length(omega)-2);
 omega_smooth2(length(omega)) = omega_smooth2(length(omega)-1);
 
 wheel_w_smooth=omega_smooth2;
 
 figure
 plot(angle);
 figure
 plot(wheel_w_smooth);
 
 
%==========================================================================================


p3=0.0227;
p4=-0.2515;

% ���ɨ�
data=buf(:,1);
theta = data(33:36);
w = w_smooth(33:36);

%���t��
wheel_data=buf(:,2);
wheel_theta = wheel_data(33:36);
wheel_w=wheel_w_smooth(33:36);

for i=1:(length(w)-1)
    W(i) = (w(i+1) - w(i))/0.1;
end
W(length(w)) = W(length(w)-1);

for i=1:(length(w)-1)
    wheel_W(i) = (wheel_w(i+1) - wheel_w(i))/0.1;
end
wheel_W(length(w)) = wheel_W(length(w)-1);


% A = zeros(length(w),2);
% A(:,1) = w';
% A(:,2) = sin(theta');
% b = transpose(W);

A2 = zeros(length(wheel_w),2);
A2(:,1) = wheel_W';

A2(:,2) = cos(theta')*wheel_W';
b2=-W'+p3*(wheel_w')+p4*sin(theta)+p3*w';

x = inv(transpose(A2)*A2)*transpose(A2)*b2;

rho1 = x(1)
rho2 = x(2)

A3 = zeros(length(wheel_w),5);
A3(:,1) = W';
A3(:,2) = (2*cos(W)- (sin(2*theta')*sec(theta))'*w)';
A3(:,3) = -w';
A3(:,4) = wheel_w';
A3(:,5) = -4.95;
b3 = -wheel_W';

AA= inv(transpose(A3)*A3)*transpose(A3);
x = inv(transpose(A3)*A3)*transpose(A3)*b3;
sigma1=x(1)*2*3.14/360  
sigma2=x(2)*2*3.14/360  
sigma3=x(3)*2*3.14/360  
sigma4=x(4)*2*3.14/360  
sigma5=x(5)*2*3.14/360  



